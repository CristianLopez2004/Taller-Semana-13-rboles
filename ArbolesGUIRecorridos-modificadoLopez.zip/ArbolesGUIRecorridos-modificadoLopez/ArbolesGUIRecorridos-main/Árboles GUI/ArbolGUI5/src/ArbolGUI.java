

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.util.Objects;

public class ArbolGUI {
    private JTable tbMatrizAdyacencia;
    private JTextArea textArea;
    private JTextField txtRaiz; // Ahora para el padre del nuevo nodo o el nodo a eliminar
    private JButton btnAgregarNodo;
    private JButton btnDibujarArbol;
    private JButton btnRecorridoAnchura;
    private JButton btnRecorridoProfundidad;
    private JButton btnPreorden;
    private JButton btnInorden;
    private JLabel lblNodo; // Podría usarse para la etiqueta del nuevo nodo, pero se genera automáticamente
    private JLabel lblRaiz; // Usado para "Raíz" o "Padre"
    private JLabel lblHoja; // Se renombra a lblPosicionHijo para claridad
    private JComboBox<Arbol.PosicionHijo> cbPosicionHijo; // Cambia el tipo y propósito
    private JPanel panelArbol;
    private JPanel panelGeneral;
    private JPanel panelDatos;
    private JLabel lblRecorridos;
    private JButton btnPostorden;
    private JButton btnMatrizAdyacencia;
    private JButton btnEliminarNodo; // Nuevo botón para eliminar nodos
    private JTextField txtNodoAEliminar; // Nuevo campo para la etiqueta del nodo a eliminar


    private Arbol arbol = new Arbol();
    private ArbolGrafico arbolGrafico; // Se inicializa en el constructor para asegurar que panelArbol existe
    private DefaultTableModel modeloTabla = new DefaultTableModel();

    public ArbolGUI() {
        // Inicializar arbolGrafico después de que panelArbol esté disponible (si es desde un diseñador)
        // O si panelArbol se inicializa en el constructor del formulario.
        // Asumiendo que el diseñador de UI de IntelliJ lo inicializa correctamente.
        arbolGrafico = new ArbolGrafico(arbol);

        panelArbol.add(arbolGrafico, BorderLayout.CENTER);

        // Configurar JComboBox para las posiciones de los hijos
        // La enumeración PosicionHijo del Arbol se usa aquí
        cbPosicionHijo.setModel(new DefaultComboBoxModel<>(Arbol.PosicionHijo.values()));
        // Asegurarse de que el JLabel 'lblHoja' tenga un texto descriptivo, por ejemplo "Posición Hijo:"
        // (Esto se haría en el diseñador de UI o aquí manualmente: lblHoja.setText("Posición Hijo:");)

        // Asignar el ArbolGrafico al panelArbol para que pueda dibujar
        // Esto es crucial para que el ArbolGrafico sea el "canvas"
        panelArbol.setLayout(new BorderLayout()); // Asegurarse de que panelArbol tenga un layout para añadir arbolGrafico
        panelArbol.add(arbolGrafico, BorderLayout.CENTER); // Añadir el panel de dibujo


        btnAgregarNodo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String etiquetaNuevoNodo = arbol.getEtiquetaNodoSiguiente(); // Genera A, B, C, etc.
                    Nodo nuevoNodo = new Nodo(0, 0, etiquetaNuevoNodo); // Coords iniciales 0,0

                    String etiquetaPadre = txtRaiz.getText().trim();
                    Nodo nodoPadre = null;

                    // Buscar el nodo padre en la lista de nodos existentes
                    if (!etiquetaPadre.isEmpty()) {
                        for (Nodo nodo : arbol.getNodos()) {
                            if (nodo.etiqueta.equals(etiquetaPadre)) {
                                nodoPadre = nodo;
                                break;
                            }
                        }
                        if (nodoPadre == null) {
                            JOptionPane.showMessageDialog(null, "Error: Nodo padre '" + etiquetaPadre + "' no encontrado.", "Error de Inserción", JOptionPane.ERROR_MESSAGE);
                            // Decrementar numNodos si no se pudo añadir para que la etiqueta no se pierda
                            arbol.getEtiquetaNodoSiguiente(); // Revierto el incremento de numNodos, es un truco
                            int tempNumNodos = arbol.getNodos().size(); // Esto es un hack. Lo ideal sería que getEtiqueta... no auto-incremente.
                            // La solución correcta sería pasar el numNodos como parámetro o que Arbol gestione bien las etiquetas al añadir.
                            // Por ahora, se asume que si falla, la etiqueta se "pierde" o se reajusta manualmente.
                            // Mejor: arbol.numNodos--; // Asumiendo que numNodos es accesible o se hace un método.
                            // Dado que no puedo modificar Arbol.numNodos directamente, y getEtiquetaNodoSiguiente() SIEMPRE incrementa,
                            // tendremos que vivir con el hecho de que una etiqueta generada pero no usada se "pierde".
                            return;
                        }
                    } else {
                        // Si etiquetaPadre está vacía, estamos intentando añadir la raíz.
                        // Solo permitimos añadir la raíz si el árbol está vacío.
                        if (arbol.getRaiz() != null) {
                            JOptionPane.showMessageDialog(null, "Error: La raíz ya existe. Ingrese un nodo padre para añadir hijos.", "Error de Inserción", JOptionPane.ERROR_MESSAGE);
                            arbol.getEtiquetaNodoSiguiente(); // Pierde la etiqueta generada.
                            return;
                        }
                    }

                    // Obtener la posición del hijo seleccionada
                    Arbol.PosicionHijo posicion = (Arbol.PosicionHijo) Objects.requireNonNull(cbPosicionHijo.getSelectedItem());

                    arbol.anadirNodo(nuevoNodo, nodoPadre, posicion);
                    imprimirArbol();
                    panelArbol.repaint(); // Solicitar un repintado del panel de dibujo

                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(null, "Error al agregar nodo: " + ex.getMessage(), "Error de Lógica de Árbol", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error inesperado al agregar nodo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace(); // Para depuración
                }
            }
        });

        // Nuevo botón para eliminar nodo
        btnEliminarNodo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String etiquetaAEliminar = txtNodoAEliminar.getText().trim();
                if (etiquetaAEliminar.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese la etiqueta del nodo a eliminar.", "Entrada Requerida", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                int confirm = JOptionPane.showConfirmDialog(null,
                        "¿Está seguro de que desea eliminar el nodo '" + etiquetaAEliminar + "' y todo su subárbol?",
                        "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    if (arbol.eliminarNodo(etiquetaAEliminar)) {
                        JOptionPane.showMessageDialog(null, "Nodo '" + etiquetaAEliminar + "' y su subárbol eliminados correctamente.", "Eliminación Exitosa", JOptionPane.INFORMATION_MESSAGE);
                        imprimirArbol(); // Actualizar la lista de nodos
                        panelArbol.repaint(); // Redibujar el árbol
                    } else {
                        JOptionPane.showMessageDialog(null, "Nodo '" + etiquetaAEliminar + "' no encontrado o no se pudo eliminar.", "Error de Eliminación", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });


        btnRecorridoAnchura.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String resultado = arbol.bfs();
                textArea.append("Recorrido en Anchura (BFS): " + resultado + "\n");
            }
        });
        btnRecorridoProfundidad.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String resultado = arbol.dfs();
                textArea.append("Recorrido en Profundidad (DFS): " + resultado + "\n");
            }
        });
        btnPreorden.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String resultado = arbol.preorden();
                textArea.append("Preorden: " + resultado + "\n");
            }
        });
        btnInorden.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String resultado = arbol.inorden();
                textArea.append("Inorden (adaptado para cuaternario): " + resultado + "\n");
            }
        });
        btnPostorden.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String resultado = arbol.postorden();
                textArea.append("Postorden: " + resultado + "\n");
            }
        });
        btnMatrizAdyacencia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarMatrizAdyacencia();
            }
        });
        btnDibujarArbol.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Simplemente solicita un repintado del panel que contiene el ArbolGrafico
                panelArbol.repaint();
            }
        });
    }

    /**
     * Actualiza el JTextArea con la lista actual de nodos en el árbol.
     */
    private void imprimirArbol() {
        textArea.setText(""); // Limpiar antes de imprimir
        textArea.append("Nodos en el Árbol:\n");
        if (arbol.getNodos().isEmpty()) {
            textArea.append("El árbol está vacío.\n");
        } else {
            for (Nodo nodo : arbol.getNodos()) {
                textArea.append(nodo.etiqueta + ": " + nodo.toString() + "\n");
            }
        }
    }

    /**
     * Muestra la matriz de adyacencia en el JTable.
     */
    private void mostrarMatrizAdyacencia() {
        Object[][] matriz = arbol.getMatrizAdyacencia();
        // Generar nombres de columnas (A, B, C...) basados en el número de nodos
        String[] nombreColumnas = new String[matriz.length];
        for (int i = 0; i < matriz.length; i++) {
            // Asume que las etiquetas son alfabéticas secuenciales A, B, C...
            nombreColumnas[i] = String.valueOf((char) ('A' + i));
        }

        // Si la tabla no tiene modelo o es nulo, se crea uno nuevo
        if (tbMatrizAdyacencia.getModel() == null || !(tbMatrizAdyacencia.getModel() instanceof DefaultTableModel)) {
            modeloTabla = new DefaultTableModel();
            tbMatrizAdyacencia.setModel(modeloTabla);
        }

        modeloTabla.setDataVector(matriz, nombreColumnas);
        // Opcional: Asegurarse de que las cabeceras de fila también se muestren si se desea (más complejo con JTable)
        // Para una matriz de adyacencia, las cabeceras de fila suelen ser las mismas que las de columna.
        // Esto no es directamente soportado por DefaultTableModel sin extenderlo o usar RowHeader.
    }

    public static void main(String[] args) {
        // Ejecutar la creación de la GUI en el Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("Árbol Cuaternario Gráfico");
                ArbolGUI arbolGUI = new ArbolGUI(); // Instancia de la GUI
                frame.setContentPane(arbolGUI.panelGeneral); // Asume que panelGeneral es la raíz del formulario
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.pack(); // Empaquetar el frame para que los componentes tengan su tamaño preferido
                frame.setLocationRelativeTo(null); // Centrar el frame en la pantalla
                frame.setVisible(true);

                // Llamar a imprimirArbol y repaint inicialmente para mostrar el estado vacío o la raíz si se añade automáticamente
                arbolGUI.imprimirArbol();
                arbolGUI.panelArbol.repaint(); // Asegurarse de que el canvas inicial esté limpio.
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
