

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.HashMap;
import java.util.Map;

public class Arbol {
    private Nodo raiz;
    private ArrayList<Nodo> nodos;
    private int numNodos; // Para la generación de etiquetas secuenciales

    // Enumeración para identificar la posición del hijo
    public enum PosicionHijo {
        HIJO1, HIJO2, HIJO3, HIJO4
    }

    public Arbol() {
        raiz = null;
        nodos = new ArrayList<>();
        numNodos = 0;
    }


    public void anadirNodo(Nodo nuevoNodo, Nodo padre, PosicionHijo posicion) {
        if (padre == null) {
            if (raiz == null) {
                raiz = nuevoNodo;
            } else {
                throw new IllegalArgumentException("La raíz ya existe. No se puede añadir otra raíz.");
            }
        } else {
            // Lógica para adjuntar el nuevo nodo en la posición especificada
            switch (posicion) {
                case HIJO1:
                    if (padre.hijo1 == null) {
                        padre.hijo1 = nuevoNodo;
                    } else {
                        throw new IllegalArgumentException("El Hijo 1 ya existe para este padre.");
                    }
                    break;
                case HIJO2:
                    if (padre.hijo2 == null) {
                        padre.hijo2 = nuevoNodo;
                    } else {
                        throw new IllegalArgumentException("El Hijo 2 ya existe para este padre.");
                    }
                    break;
                case HIJO3:
                    if (padre.hijo3 == null) {
                        padre.hijo3 = nuevoNodo;
                    } else {
                        throw new IllegalArgumentException("El Hijo 3 ya existe para este padre.");
                    }
                    break;
                case HIJO4:
                    if (padre.hijo4 == null) {
                        padre.hijo4 = nuevoNodo;
                    } else {
                        throw new IllegalArgumentException("El Hijo 4 ya existe para este padre.");
                    }
                    break;
                default:
                    throw new IllegalArgumentException("Posición de hijo no válida.");
            }
        }
        nodos.add(nuevoNodo); // Asegura que todos los nodos estén en la lista para operaciones generales
    }


    public boolean eliminarNodo(String etiquetaNodo) {
        if (raiz == null) {
            return false;
        }

        if (raiz.etiqueta.equals(etiquetaNodo)) {
            // Si la raíz es el nodo a eliminar, se vacía todo el árbol
            raiz = null;
            nodos.clear(); // Elimina todos los nodos de la lista
            numNodos = 0; // Reinicia el contador de nodos
            return true;
        }

        Nodo nodoPadre = encontrarPadre(raiz, etiquetaNodo);
        if (nodoPadre != null) {
            Nodo nodoAEliminar = null;
            PosicionHijo pos = null;

            if (nodoPadre.hijo1 != null && nodoPadre.hijo1.etiqueta.equals(etiquetaNodo)) {
                nodoAEliminar = nodoPadre.hijo1;
                nodoPadre.hijo1 = null; // Desconectar
                pos = PosicionHijo.HIJO1;
            } else if (nodoPadre.hijo2 != null && nodoPadre.hijo2.etiqueta.equals(etiquetaNodo)) {
                nodoAEliminar = nodoPadre.hijo2;
                nodoPadre.hijo2 = null; // Desconectar
                pos = PosicionHijo.HIJO2;
            } else if (nodoPadre.hijo3 != null && nodoPadre.hijo3.etiqueta.equals(etiquetaNodo)) {
                nodoAEliminar = nodoPadre.hijo3;
                nodoPadre.hijo3 = null; // Desconectar
                pos = PosicionHijo.HIJO3;
            } else if (nodoPadre.hijo4 != null && nodoPadre.hijo4.etiqueta.equals(etiquetaNodo)) {
                nodoAEliminar = nodoPadre.hijo4;
                nodoPadre.hijo4 = null; // Desconectar
                pos = PosicionHijo.HIJO4;
            }

            if (nodoAEliminar != null) {
                // Eliminar el nodo y su subárbol de la lista general de nodos
                eliminarSubarbolDeLista(nodoAEliminar);
                return true;
            }
        }
        return false;
    }


    private Nodo encontrarPadre(Nodo actual, String etiquetaHijo) {
        if (actual == null) {
            return null;
        }

        // Revisar si alguno de los hijos es el nodo buscado
        if ((actual.hijo1 != null && actual.hijo1.etiqueta.equals(etiquetaHijo)) ||
                (actual.hijo2 != null && actual.hijo2.etiqueta.equals(etiquetaHijo)) ||
                (actual.hijo3 != null && actual.hijo3.etiqueta.equals(etiquetaHijo)) ||
                (actual.hijo4 != null && actual.hijo4.etiqueta.equals(etiquetaHijo))) {
            return actual;
        }

        // Búsqueda recursiva en los hijos
        Nodo padreEncontrado = encontrarPadre(actual.hijo1, etiquetaHijo);
        if (padreEncontrado != null) return padreEncontrado;

        padreEncontrado = encontrarPadre(actual.hijo2, etiquetaHijo);
        if (padreEncontrado != null) return padreEncontrado;

        padreEncontrado = encontrarPadre(actual.hijo3, etiquetaHijo);
        if (padreEncontrado != null) return padreEncontrado;

        padreEncontrado = encontrarPadre(actual.hijo4, etiquetaHijo);
        return padreEncontrado;
    }


    private void eliminarSubarbolDeLista(Nodo nodo) {
        if (nodo == null) {
            return;
        }
        nodos.remove(nodo); // Eliminar el nodo actual
        eliminarSubarbolDeLista(nodo.hijo1);
        eliminarSubarbolDeLista(nodo.hijo2);
        eliminarSubarbolDeLista(nodo.hijo3);
        eliminarSubarbolDeLista(nodo.hijo4);
    }

    public ArrayList<Nodo> getNodos() {
        return nodos;
    }

    public Nodo getRaiz() {
        return raiz;
    }


    public String getEtiquetaNodoSiguiente() {
        return String.valueOf((char) ('A' + numNodos++));
    }


    public String bfs() {
        if (raiz == null) return "";

        StringBuilder resultado = new StringBuilder();
        Queue<Nodo> queue = new LinkedList<>();
        queue.add(raiz);

        while (!queue.isEmpty()) {
            Nodo nodo = queue.poll();
            resultado.append(nodo.etiqueta).append(" ");
            // Añadir hijos en un orden consistente (ej. Hijo1, Hijo2, Hijo3, Hijo4)
            if (nodo.hijo1 != null) queue.add(nodo.hijo1);
            if (nodo.hijo2 != null) queue.add(nodo.hijo2);
            if (nodo.hijo3 != null) queue.add(nodo.hijo3);
            if (nodo.hijo4 != null) queue.add(nodo.hijo4);
        }

        return resultado.toString().trim();
    }


    public String dfs() {
        if (raiz == null) return "";

        StringBuilder resultado = new StringBuilder();
        Stack<Nodo> stack = new Stack<>();
        stack.push(raiz);

        while (!stack.isEmpty()) {
            Nodo nodo = stack.pop();
            resultado.append(nodo.etiqueta).append(" ");
            // Apilar hijos en orden inverso al deseado de visita para que el primer hijo deseado sea el último en apilarse
            // y, por lo tanto, el primero en desapilarse (LIFO).
            // Si queremos visitar en orden Hijo1, Hijo2, Hijo3, Hijo4, apilamos en orden Hijo4, Hijo3, Hijo2, Hijo1.
            if (nodo.hijo4 != null) stack.push(nodo.hijo4);
            if (nodo.hijo3 != null) stack.push(nodo.hijo3);
            if (nodo.hijo2 != null) stack.push(nodo.hijo2);
            if (nodo.hijo1 != null) stack.push(nodo.hijo1);
        }

        return resultado.toString().trim();
    }


    public String preorden() {
        return preordenImpresion(raiz).trim();
    }

    private String preordenImpresion(Nodo nodo) {
        if (nodo == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(nodo.etiqueta).append(" ");
        sb.append(preordenImpresion(nodo.hijo1));
        sb.append(preordenImpresion(nodo.hijo2));
        sb.append(preordenImpresion(nodo.hijo3));
        sb.append(preordenImpresion(nodo.hijo4));
        return sb.toString();
    }


    public String inorden() {
        return inordenImpresion(raiz).trim();
    }

    private String inordenImpresion(Nodo nodo) {
        if (nodo == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(inordenImpresion(nodo.hijo1)); // Visita Hijo1
        sb.append(nodo.etiqueta).append(" ");     // Visita Raíz
        sb.append(inordenImpresion(nodo.hijo2)); // Visita Hijo2
        sb.append(inordenImpresion(nodo.hijo3)); // Visita Hijo3
        sb.append(inordenImpresion(nodo.hijo4)); // Visita Hijo4
        return sb.toString();
    }


    public String postorden() {
        return postordenImpresion(raiz).trim();
    }

    private String postordenImpresion(Nodo nodo) {
        if (nodo == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(postordenImpresion(nodo.hijo1));
        sb.append(postordenImpresion(nodo.hijo2));
        sb.append(postordenImpresion(nodo.hijo3));
        sb.append(postordenImpresion(nodo.hijo4));
        sb.append(nodo.etiqueta).append(" ");
        return sb.toString();
    }


    public Object[][] getMatrizAdyacencia() {
        int tam = nodos.size();
        Object[][] matriz = new Object[tam][tam];
        Map<String, Integer> etiquetaAIndice = new HashMap<>();

        // Inicializar matriz y mapeo de etiquetas a índices
        for (int i = 0; i < tam; i++) {
            etiquetaAIndice.put(nodos.get(i).etiqueta, i);
            for (int j = 0; j < tam; j++) {
                matriz[i][j] = 0;
            }
        }

        // Llenar la matriz con las conexiones
        for (Nodo nodo : nodos) {
            int desdeIndice = etiquetaAIndice.get(nodo.etiqueta);
            if (nodo.hijo1 != null) {
                int hastaIndice = etiquetaAIndice.get(nodo.hijo1.etiqueta);
                matriz[desdeIndice][hastaIndice] = 1;
            }
            if (nodo.hijo2 != null) {
                int hastaIndice = etiquetaAIndice.get(nodo.hijo2.etiqueta);
                matriz[desdeIndice][hastaIndice] = 1;
            }
            if (nodo.hijo3 != null) {
                int hastaIndice = etiquetaAIndice.get(nodo.hijo3.etiqueta);
                matriz[desdeIndice][hastaIndice] = 1;
            }
            if (nodo.hijo4 != null) {
                int hastaIndice = etiquetaAIndice.get(nodo.hijo4.etiqueta);
                matriz[desdeIndice][hastaIndice] = 1;
            }
        }

        return matriz;
    }
}