

import javax.swing.*;
import java.awt.*;
import java.util.*;

public class ArbolGrafico extends JPanel {
    private Arbol arbol;

    public ArbolGrafico (Arbol arbol) {
        this.arbol = arbol;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Configuración de renderizado para mejor calidad visual
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setStroke(new BasicStroke(1.5f)); // Grosor de línea

        // Obtener el tamaño del panel
        int panelWidth = getWidth();
        int panelHeight = getHeight();

        // Calcular la posición inicial (centrado en el panel)
        int x = panelWidth / 2;
        int y = 50; // Un valor fijo para la raíz del árbol, desde arriba

        // Dimensiones para los nodos hijos
        int dimensionXInicial = panelWidth / 5; // Mayor espacio inicial para los 4 hijos
        int dimensionY = 60; // Separación vertical entre niveles

        // Dibujar el árbol
        dibujarArbol(g2d, arbol.getRaiz(), x, y, dimensionXInicial, dimensionY);
    }


    public void dibujarArbol(Graphics2D g2d, Nodo nodo, int x, int y, int dimensionX, int dimensionY) {
        if (nodo != null) {
            // Dibuja el nodo actual
            g2d.setColor(Color.BLUE); // Color del nodo
            g2d.fillOval(x - 15, y - 15, 30, 30);
            g2d.setColor(Color.WHITE); // Color del texto del nodo
            g2d.drawString(nodo.etiqueta, x - 10, y + 5);

            // Asigna las coordenadas del nodo actual (útil si se necesita su posición en otro lugar)
            nodo.x = x;
            nodo.y = y;

            // Calcular las posiciones relativas para los 4 hijos
            int childDimensionX = dimensionX / 2; // La dimensión X para los hijos se reduce a la mitad en cada nivel.
            int horizontalSpacing = childDimensionX; // Espaciado horizontal base

            // Dibujar líneas y llamar recursivamente para cada hijo
            g2d.setColor(Color.DARK_GRAY); // Color de las líneas

            // HIJO 1 (Noroeste o Extremo Izquierdo)
            if (nodo.hijo1 != null) {
                // CORRECCIÓN: Casteo explícito a int para evitar "possible lossy conversion from double to int"
                int childX = x - (int)(horizontalSpacing * 1.5);
                int childY = y + dimensionY;
                g2d.drawLine(x, y + 15, childX, childY - 15);
                dibujarArbol(g2d, nodo.hijo1, childX, childY, childDimensionX, dimensionY);
            }

            // HIJO 2 (Noreste o Segundo de Izquierda a Derecha)
            if (nodo.hijo2 != null) {
                // CORRECCIÓN: Casteo explícito a int
                int childX = x - (int)(horizontalSpacing * 0.5);
                int childY = y + dimensionY;
                g2d.drawLine(x, y + 15, childX, childY - 15);
                dibujarArbol(g2d, nodo.hijo2, childX, childY, childDimensionX, dimensionY);
            }

            // HIJO 3 (Suroeste o Tercero de Izquierda a Derecha)
            if (nodo.hijo3 != null) {
                // CORRECCIÓN: Casteo explícito a int
                int childX = x + (int)(horizontalSpacing * 0.5);
                int childY = y + dimensionY;
                g2d.drawLine(x, y + 15, childX, childY - 15);
                dibujarArbol(g2d, nodo.hijo3, childX, childY, childDimensionX, dimensionY);
            }

            // HIJO 4 (Sureste o Extremo Derecho)
            if (nodo.hijo4 != null) {
                // CORRECCIÓN: Casteo explícito a int
                int childX = x + (int)(horizontalSpacing * 1.5);
                int childY = y + dimensionY;
                g2d.drawLine(x, y + 15, childX, childY - 15);
                dibujarArbol(g2d, nodo.hijo4, childX, childY, childDimensionX, dimensionY);
            }
        }
    }
}