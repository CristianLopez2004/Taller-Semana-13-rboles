

public class Nodo {
    int x, y;
    String etiqueta;
    // Referencias a los cuatro hijos
    // Se nombran para mayor claridad, podrían ser Quadrant.NW, Quadrant.NE, etc.
    Nodo hijo1; // Noroeste o primer hijo
    Nodo hijo2; // Noreste o segundo hijo
    Nodo hijo3; // Suroeste o tercer hijo
    Nodo hijo4; // Sureste o cuarto hijo

    public Nodo(int x, int y, String etiqueta) {
        this.x = x;
        this.y = y;
        this.etiqueta = etiqueta;
        this.hijo1 = null;
        this.hijo2 = null;
        this.hijo3 = null;
        this.hijo4 = null;
    }


    @Override
    public String toString() {
        return etiqueta + " (" + x + ", " + y + ")";
    }
}